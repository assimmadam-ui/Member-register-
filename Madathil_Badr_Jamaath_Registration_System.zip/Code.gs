const SHEET_NAME = 'Registrations';

// Optional: put a committee/admin email here if you also want an email alert.
// Leave blank to disable email alerts.
const ADMIN_EMAIL = '';

function doGet() {
  return ContentService
    .createTextOutput('Madathil Badr Jamaath registration service is active.')
    .setMimeType(ContentService.MimeType.TEXT);
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);

    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow([
        'രജിസ്ട്രേഷൻ സമയം',
        'പേര്',
        'പിതാവിന്റെ പേര്',
        'UAE മൊബൈൽ',
        'WhatsApp',
        'എമിറേറ്റ്',
        'ജോലി'
      ]);
      sheet.setFrozenRows(1);
    }

    const now = new Date();
    sheet.appendRow([
      now,
      data.name || '',
      data.father || '',
      data.mobile || '',
      data.whatsapp || '',
      data.emirate || '',
      data.job || ''
    ]);

    if (ADMIN_EMAIL) {
      const subject = 'പുതിയ മഠത്തിൽ ബദർ ജമാഅത്ത് അംഗ രജിസ്ട്രേഷൻ';
      const body =
        'പേര്: ' + (data.name || '') + '\n' +
        'പിതാവിന്റെ പേര്: ' + (data.father || '') + '\n' +
        'UAE മൊബൈൽ: ' + (data.mobile || '') + '\n' +
        'WhatsApp: ' + (data.whatsapp || '') + '\n' +
        'എമിറേറ്റ്: ' + (data.emirate || '') + '\n' +
        'ജോലി: ' + (data.job || '');
      MailApp.sendEmail(ADMIN_EMAIL, subject, body);
    }

    return ContentService
      .createTextOutput(JSON.stringify({ok:true}))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ok:false, error:String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
